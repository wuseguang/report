/**
 * 
 */
$.extend({
	createTree:function(data){
		
	}
});