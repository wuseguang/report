package com.wuseguang.report.extractor;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class BeijingExtractor implements ExtractorInterface {

	@Override
	public List listEnterprise(String entName, String registeredNumber)
			throws IOException {
		// TODO Auto-generated method stub
		List result=new ArrayList();
		String queryStr=entName==null?registeredNumber:entName;
		String url="http://qyxy.baic.gov.cn/lucene/luceneAction!NetCreditLucene.dhtml?queryStr="+URLEncoder.encode(queryStr,"utf8");
		Document doc = Jsoup
				.connect(url)
				.header("Host", "qyxy.baic.gov.cn")
				.header("User-Agent",
						"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0")
				.timeout(3000).get();
		Elements companys = doc.select(".cx00");
		for (Element company : companys) {
			Element a = company.getElementsByTag("a").first();
			String compantyUri = a.attr("onclick").split("'")[1];
			if(compantyUri.length()<10)continue;
			String compantyUrl="http://qyxy.baic.gov.cn"+compantyUri.replace("&flagScztdj=flagScztdj", "");
			String compantyName=a.text();
			int beginIndex=compantyName.lastIndexOf("（");
			if(beginIndex<0)continue;
			Map compantyInfo=new HashMap();
			String compantyType=compantyName.substring(beginIndex+1,compantyName.length()-1);
			compantyName=compantyName.substring(0,beginIndex);
			System.out.println(compantyName+":"+compantyType);
			company.child(0).remove();
			String info=company.text();
			String[] infoArray=info.replaceAll("，","").split("注册号：|法定代表人：|法定代表人姓名：|住所：|一般经营项目：|经营者姓名：|经营场所：");
			//System.out.println(info);
			compantyInfo.put("enterpriseName", compantyName);
			compantyInfo.put("enterpriseState", compantyType);
			compantyInfo.put("enterpriseRegisterCode", infoArray[1].trim());
			compantyInfo.put("enterpriseLegalPerson", infoArray[2].trim());
			compantyInfo.put("enterpriseAddress", infoArray[3].trim());
			compantyInfo.put("enterpriseUrl", compantyUrl);
			System.out.println(compantyUrl);
			result.add(compantyInfo);
			//for(String i:infoArray)
			//System.out.println(i.trim());
		}
		return result;
	}

	@Override
	public Map extractEnterprise(String entUri) throws IOException {
		// TODO Auto-generated method stub
		Map info=new HashMap();
		Document doc = Jsoup
				.connect(entUri)
				.header("Host", "qyxy.baic.gov.cn")
				.header("User-Agent",
						"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0")
				.timeout(3000).get();
		Element content=doc.select(".jic").first();
		info.put("html", doc.select(".jic").html());
		Elements tables=content.select("table");
		String updateTime=tables.first().select("div").text();
		//Element 
		System.out.println(updateTime);
		return info;
	}

}
