package com.wuseguang.report.servlet.i;

import javax.servlet.http.HttpServletRequest;

public interface CompleteBean {
	 void completeBean(HttpServletRequest request);
}
