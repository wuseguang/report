package com.wuseguang.report.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class NullTest {

	@Test
	public void test() {
		Object a=null;
		System.out.println(new Boolean(null));
		//System.out.println(new String(a));
		//if(a)System.out.println("hi");
		//fail("Not yet implemented");
	}

}
